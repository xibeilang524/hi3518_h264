make clean;make
cp ../../lib/libsns_ov9712.so /home/x00226337/hi3518e/release_3518E/libs;
echo "cp down!!"
