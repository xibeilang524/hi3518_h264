1.Module parameter description

BT656 PAL:insmod adv_7179.ko norm_mode=0
BT656 NTSC:insmod adv_7179.ko norm_mode=1

BT656 PAL is defualt
